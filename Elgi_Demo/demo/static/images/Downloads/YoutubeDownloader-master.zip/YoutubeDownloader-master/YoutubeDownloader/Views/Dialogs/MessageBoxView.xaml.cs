﻿namespace YoutubeDownloader.Views.Dialogs;

public partial class MessageBoxView
{
    public MessageBoxView()
    {
        InitializeComponent();
    }
}